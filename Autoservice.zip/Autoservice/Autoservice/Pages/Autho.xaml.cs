﻿using Autoservice.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    public partial class Autho : Page
    {
        private string goha = "1234567890qwertyuiopasdfghjklmnbvcxz";
        private int counUnsuccesseful = 0;
        public Autho()
        {
            InitializeComponent();
            txtCaptcha.Visibility = Visibility.Hidden;
            textBlockCaptcha.Visibility = Visibility.Hidden;
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client());
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();
            User user = new User();
            user = Entities.Entities.GetContext().User.Where(p => p.UserLogin == login && p.UserPassword == password).FirstOrDefault();
            int userCount = Entities.Entities.GetContext().User.Where(p => p.UserLogin == login && p.UserPassword == password).Count();
            if (counUnsuccesseful < 1)
            {
                if (userCount > 0)
                {
                    MessageBox.Show("Вы пошли под: " + user.Role.RoleName.ToString());
                    LoadForm(user.Role.RoleName.ToString());

                }
            }
            else
            {
                MessageBox.Show("Введите данные заново!");
            }
        }
        private void GenerateCaptcha()
        {
            txtCaptcha.Visibility = Visibility.Visible;
            textBlockCaptcha.Visibility = Visibility.Visible;

            Random rnd = new Random();
            var LengthWord = rnd.Next(5, 10);
            for (int i = 0; i < LengthWord; i++)
            {

            }
        }
        private void LoadForm(string role)
        {
            switch (role)
            {
                case "Клиент":
                    NavigationService.Navigate(new Client());
                    break;
            }

        }
    }
}

